import React from "react";
import ReactDOM from "react-dom/client";

const App = () => {
  return <h1>Bienvenue sur le Défi TEF 31 Jours!</h1>;
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
